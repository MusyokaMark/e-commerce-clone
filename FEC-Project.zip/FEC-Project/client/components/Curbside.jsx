import React, { useEffect, useState } from "react";

const Curbside = () => {
  return;
};

export default Curbside;
