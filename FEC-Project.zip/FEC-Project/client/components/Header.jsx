import React, { useEffect, useState } from "react";
import Navbar from "./Navbar.jsx";
import CurrPromotion from "./CurrPromotion.jsx";
import NewNavbar from "./NewNavbar.jsx";

const Header = (props) => {
  return (
    <main>
      <CurrPromotion />
      <NewNavbar />
      {/* <Navbar /> */}
    </main>
  );
};

export default Header;
