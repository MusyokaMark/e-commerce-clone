import React, { useEffect, useState } from "react";

const Location = () => {
  return;
};

export default Location;
