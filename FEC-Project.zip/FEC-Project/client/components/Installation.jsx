import React, { useEffect, useState } from "react";

const Installation = () => {
  return;
};

export default Installation;
