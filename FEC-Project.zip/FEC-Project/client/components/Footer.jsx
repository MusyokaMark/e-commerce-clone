import React, { useEffect, useState } from "react";

const Footer = () => {
  return;
};

export default Footer;
