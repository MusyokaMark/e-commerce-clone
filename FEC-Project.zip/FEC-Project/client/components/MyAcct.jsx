import React, { useEffect, useState } from "react";

const MyAcct = () => {
  return;
};

export default MyAcct;
