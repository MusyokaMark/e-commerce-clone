import React, { useEffect, useState } from "react";

const MobileApp = () => {
  return;
};

export default MobileApp;
