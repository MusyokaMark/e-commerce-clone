import React, { useEffect, useState } from "react";

const Categories = () => {
  return;
};

export default Categories;
