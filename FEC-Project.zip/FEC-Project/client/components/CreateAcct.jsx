import React, { useEffect, useState } from "react";

const CreateAcct = () => {
  return;
};

export default CreateAcct;
