import React, { useEffect, useState } from "react";

const RecentView = () => {
  return;
};

export default RecentView;
