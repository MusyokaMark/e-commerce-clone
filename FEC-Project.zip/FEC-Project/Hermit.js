var a=5;  
var b=1;